﻿using System.Resources;
using System.Reflection;
using System.Runtime.CompilerServices;


[assembly: AssemblyTitle("Math.NET Numerics for Unity")]
[assembly: AssemblyDescription("Math.NET Numerics, providing methods and algorithms for numerical " +
  "computations in science, engineering and every day use. This version is a port from Math.NET numerics " +
  "for Unity3D.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Bismur Studios Ltd.")]
[assembly: AssemblyProduct("Math.NET Numerics for Unity")]
[assembly: AssemblyCopyright("Bismur Studios Ltd. (c) 2016-2017")]
[assembly: NeutralResourcesLanguage("en")]

[assembly: InternalsVisibleTo("Assembly-CSharp-Editor")]
[assembly: InternalsVisibleTo("MathNet.Numerics.Tests")]

[assembly: AssemblyVersion("1.0.1.*")]
[assembly: AssemblyFileVersion("1.0.1.*")]
[assembly: AssemblyInformationalVersion("1.0.1")]









