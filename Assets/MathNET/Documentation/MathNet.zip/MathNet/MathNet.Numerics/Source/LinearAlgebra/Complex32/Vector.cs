﻿// Unity Asset Store License
//
// Copyright (c) 2016-2017 Bismur Studios Ltd.
// Copyright (c) 2016-2017 Ioannis Giagkiozis
//
// Math.NET for Unity is released under the Unity Asset Store 
// Terms of Service and EULA https://unity3d.com/legal/as_terms
// here-forth referred to simply as EULA.
// 
// Math.NET for Unity is a Non-Restricted Asset, as such section 2.2.2 
// of the EULA does not apply. Section 2.2.1 is applicable to Math.NET 
// for Unity, reproduced below:
// 
// 2.2.1 Non-Restricted Assets. The following concerns only Assets that 
// are not Restricted Assets: 
// Licensor grants to the END-USER a non-exclusive, worldwide, and 
// perpetual license to the Asset to integrate Assets only as incorporated 
// and embedded components of electronic games and interactive media 
// and distribute such electronic game and interactive media. Except for 
// game services software development kits (“Services SDKs”), END-USERS 
// may modify Assets. END-USER may otherwise not reproduce, distribute, 
// sublicense, rent, lease or lend the Assets. It is emphasized that the 
// END-USERS shall not be entitled to distribute or transfer in any way 
// (including, without, limitation by way of sublicense) the Assets in any 
// other way than as integrated components of electronic games and 
// interactive media. Without limitation of the foregoing it is emphasized 
// that END-USER shall not be entitled to share the costs related to purchasing 
// an Asset and then let any third party that has contributed to such purchase 
// use such Asset (forum pooling).
// 
// All other sections of the EULA apply.
// 
// Vector.cs is part of Math.NET for Unity.
// 
// A version of this file was part of Math.NET Numerics. 
// Vector.cs is a modified version of Vector.cs in Math.NET Numerics.
//
// ----------------------------------------------------------------------------
// License of the un-modified version of Vector.cs
// ----------------------------------------------------------------------------
//
// <copyright file="Vector.cs" company="Math.NET">
// Math.NET Numerics, part of the Math.NET Project
// http://numerics.mathdotnet.com
// http://github.com/mathnet/mathnet-numerics
//
// Copyright (c) 2009-2015 Math.NET
//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

using System;
using MathNet.Numerics.LinearAlgebra.Storage;
using MathNet.Numerics.Threading;


namespace MathNet.Numerics.LinearAlgebra.Complex32 {

  /// <summary>
  ///   <c>Complex32</c> version of the <see cref="Vector{T}"/> class.
  /// </summary>
  [Serializable]
  public abstract class Vector : Vector<Numerics.Complex32> {
    /// <summary>
    ///   Set all values whose absolute value is smaller than the threshold to zero.
    /// </summary>
    public override void CoerceZero(double threshold) {
      MapInplace(x => x.Magnitude < threshold ? Numerics.Complex32.Zero : x, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Returns the value of the absolute minimum element.
    /// </summary>
    /// <returns>The value of the absolute minimum element.</returns>
    public sealed override Numerics.Complex32 AbsoluteMinimum() {
      return At(AbsoluteMinimumIndex()).Magnitude;
    }

    /// <summary>
    ///   Returns the index of the absolute minimum element.
    /// </summary>
    /// <returns>The index of absolute minimum element.</returns>
    public override int AbsoluteMinimumIndex() {
      var index = 0;
      var min = At(index).Magnitude;
      for(var i = 1; i < Count; i++) {
        var test = At(i).Magnitude;
        if(test < min) {
          index = i;
          min = test;
        }
      }

      return index;
    }

    /// <summary>
    ///   Returns the value of the absolute maximum element.
    /// </summary>
    /// <returns>The value of the absolute maximum element.</returns>
    public override Numerics.Complex32 AbsoluteMaximum() {
      return At(AbsoluteMaximumIndex()).Magnitude;
    }

    /// <summary>
    ///   Returns the index of the absolute maximum element.
    /// </summary>
    /// <returns>The index of absolute maximum element.</returns>
    public override int AbsoluteMaximumIndex() {
      var index = 0;
      var max = At(index).Magnitude;
      for(var i = 1; i < Count; i++) {
        var test = At(i).Magnitude;
        if(test > max) {
          index = i;
          max = test;
        }
      }

      return index;
    }

    /// <summary>
    ///   Computes the sum of the vector's elements.
    /// </summary>
    /// <returns>The sum of the vector's elements.</returns>
    public override Numerics.Complex32 Sum() {
      var sum = Numerics.Complex32.Zero;
      for(var i = 0; i < Count; i++)
        sum += At(i);

      return sum;
    }

    /// <summary>
    ///   Calculates the L1 norm of the vector, also known as Manhattan norm.
    /// </summary>
    /// <returns>The sum of the absolute values.</returns>
    public override double L1Norm() {
      double sum = 0d;
      for(var i = 0; i < Count; i++)
        sum += At(i).Magnitude;

      return sum;
    }

    /// <summary>
    ///   Calculates the L2 norm of the vector, also known as Euclidean norm.
    /// </summary>
    /// <returns>The square root of the sum of the squared values.</returns>
    public override double L2Norm() {
      return DoConjugateDotProduct(this).SquareRoot().Real;
    }

    /// <summary>
    ///   Calculates the infinity norm of the vector.
    /// </summary>
    /// <returns>The maximum absolute value.</returns>
    public override double InfinityNorm() {
      return CommonParallel.Aggregate(0, Count, i => At(i).Magnitude, Math.Max, 0f);
    }

    /// <summary>
    ///   Computes the p-Norm.
    /// </summary>
    /// <param name="p">
    ///   The p value.
    /// </param>
    /// <returns>
    ///   <c>Scalar ret = ( ∑|At(i)|^p )^(1/p)</c>
    /// </returns>
    public override double Norm(double p) {
      if(p < 0d)
        throw new ArgumentOutOfRangeException("p");

      if(p == 1d)
        return L1Norm();
      if(p == 2d)
        return L2Norm();
      if(double.IsPositiveInfinity(p))
        return InfinityNorm();

      double sum = 0d;
      for(var index = 0; index < Count; index++)
        sum += Math.Pow(At(index).Magnitude, p);

      return Math.Pow(sum, 1.0 / p);
    }

    /// <summary>
    ///   Returns the index of the maximum element.
    /// </summary>
    /// <returns>The index of maximum element.</returns>
    public override int MaximumIndex() {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Returns the index of the minimum element.
    /// </summary>
    /// <returns>The index of minimum element.</returns>
    public override int MinimumIndex() {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Normalizes this vector to a unit vector with respect to the p-norm.
    /// </summary>
    /// <param name="p">
    ///   The p value.
    /// </param>
    /// <returns>
    ///   This vector normalized to a unit vector with respect to the p-norm.
    /// </returns>
    public override Vector<Numerics.Complex32> Normalize(double p) {
      if(p < 0d)
        throw new ArgumentOutOfRangeException("p");

      double norm = Norm(p);
      var clone = Clone();
      if(norm == 0d)
        return clone;

      clone.Multiply((float)(1d / norm), clone);

      return clone;
    }

    /// <summary>
    ///   Conjugates vector and save result to <paramref name="result"/>
    /// </summary>
    /// <param name="result">Target vector</param>
    protected override void DoConjugate(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Conjugate, result, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Negates vector and saves result to <paramref name="result"/>
    /// </summary>
    /// <param name="result">Target vector</param>
    protected override void DoNegate(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Negate, result, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Adds a scalar to each element of the vector and stores the result in the result vector.
    /// </summary>
    /// <param name="scalar">
    ///   The scalar to add.
    /// </param>
    /// <param name="result">
    ///   The vector to store the result of the addition.
    /// </param>
    protected override void DoAdd(Numerics.Complex32 scalar, Vector<Numerics.Complex32> result) {
      Map(x => x + scalar, result, Zeros.Include);
    }

    /// <summary>
    ///   Adds another vector to this vector and stores the result into the result vector.
    /// </summary>
    /// <param name="other">
    ///   The vector to add to this one.
    /// </param>
    /// <param name="result">
    ///   The vector to store the result of the addition.
    /// </param>
    protected override void DoAdd(Vector<Numerics.Complex32> other, Vector<Numerics.Complex32> result) {
      Map2(Numerics.Complex32.Add, other, result, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Subtracts a scalar from each element of the vector and stores the result in the result vector.
    /// </summary>
    /// <param name="scalar">
    ///   The scalar to subtract.
    /// </param>
    /// <param name="result">
    ///   The vector to store the result of the subtraction.
    /// </param>
    protected override void DoSubtract(Numerics.Complex32 scalar, Vector<Numerics.Complex32> result) {
      Map(x => x - scalar, result, Zeros.Include);
    }

    /// <summary>
    ///   Subtracts another vector to this vector and stores the result into the result vector.
    /// </summary>
    /// <param name="other">
    ///   The vector to subtract from this one.
    /// </param>
    /// <param name="result">
    ///   The vector to store the result of the subtraction.
    /// </param>
    protected override void DoSubtract(Vector<Numerics.Complex32> other, Vector<Numerics.Complex32> result) {
      Map2(Numerics.Complex32.Subtract, other, result, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Multiplies a scalar to each element of the vector and stores the result in the result vector.
    /// </summary>
    /// <param name="scalar">
    ///   The scalar to multiply.
    /// </param>
    /// <param name="result">
    ///   The vector to store the result of the multiplication.
    /// </param>
    protected override void DoMultiply(Numerics.Complex32 scalar, Vector<Numerics.Complex32> result) {
      Map(x => x * scalar, result, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Divides each element of the vector by a scalar and stores the result in the result vector.
    /// </summary>
    /// <param name="divisor">
    ///   The scalar to divide with.
    /// </param>
    /// <param name="result">
    ///   The vector to store the result of the division.
    /// </param>
    protected override void DoDivide(Numerics.Complex32 divisor, Vector<Numerics.Complex32> result) {
      Map(x => x / divisor, result, divisor.IsZero() ? Zeros.Include : Zeros.AllowSkip);
    }

    /// <summary>
    ///   Divides a scalar by each element of the vector and stores the result in the result vector.
    /// </summary>
    /// <param name="dividend">The scalar to divide.</param>
    /// <param name="result">The vector to store the result of the division.</param>
    protected override void DoDivideByThis(Numerics.Complex32 dividend, Vector<Numerics.Complex32> result) {
      Map(x => dividend / x, result, Zeros.Include);
    }

    /// <summary>
    ///   Pointwise multiplies this vector with another vector and stores the result into the result vector.
    /// </summary>
    /// <param name="other">The vector to pointwise multiply with this one.</param>
    /// <param name="result">The vector to store the result of the pointwise multiplication.</param>
    protected override void DoPointwiseMultiply(Vector<Numerics.Complex32> other, Vector<Numerics.Complex32> result) {
      Map2(Numerics.Complex32.Multiply, other, result, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Pointwise divide this vector with another vector and stores the result into the result vector.
    /// </summary>
    /// <param name="divisor">The vector to pointwise divide this one by.</param>
    /// <param name="result">The vector to store the result of the pointwise division.</param>
    protected override void DoPointwiseDivide(Vector<Numerics.Complex32> divisor, Vector<Numerics.Complex32> result) {
      Map2(Numerics.Complex32.Divide, divisor, result, Zeros.Include);
    }

    /// <summary>
    ///   Pointwise raise this vector to an exponent and store the result into the result vector.
    /// </summary>
    /// <param name="exponent">The exponent to raise this vector values to.</param>
    /// <param name="result">The vector to store the result of the pointwise power.</param>
    protected override void DoPointwisePower(Numerics.Complex32 exponent, Vector<Numerics.Complex32> result) {
      Map(x => x.Power(exponent), result, Zeros.Include);
    }

    /// <summary>
    ///   Pointwise raise this vector to an exponent vector and store the result into the result vector.
    /// </summary>
    /// <param name="exponent">The exponent vector to raise this vector values to.</param>
    /// <param name="result">The vector to store the result of the pointwise power.</param>
    protected override void DoPointwisePower(Vector<Numerics.Complex32> exponent, Vector<Numerics.Complex32> result) {
      Map2(Numerics.Complex32.Pow, exponent, result, Zeros.Include);
    }

    /// <summary>
    ///   Pointwise canonical modulus, where the result has the sign of the divisor,
    ///   of this vector with another vector and stores the result into the result vector.
    /// </summary>
    /// <param name="divisor">The pointwise denominator vector to use.</param>
    /// <param name="result">The result of the modulus.</param>
    protected sealed override void DoPointwiseModulus(Vector<Numerics.Complex32> divisor,
                                                      Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Pointwise remainder (% operator), where the result has the sign of the dividend,
    ///   of this vector with another vector and stores the result into the result vector.
    /// </summary>
    /// <param name="divisor">The pointwise denominator vector to use.</param>
    /// <param name="result">The result of the modulus.</param>
    protected sealed override void DoPointwiseRemainder(Vector<Numerics.Complex32> divisor,
                                                        Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Pointwise applies the exponential function to each value and stores the result into the result vector.
    /// </summary>
    /// <param name="result">The vector to store the result.</param>
    protected override void DoPointwiseExp(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Exp, result, Zeros.Include);
    }

    /// <summary>
    ///   Pointwise applies the natural logarithm function to each value and stores the result into the result vector.
    /// </summary>
    /// <param name="result">The vector to store the result.</param>
    protected override void DoPointwiseLog(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Log, result, Zeros.Include);
    }

    protected override void DoPointwiseAbs(Vector<Numerics.Complex32> result) {
      Map(x => (Numerics.Complex32)Numerics.Complex32.Abs(x), result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseAcos(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Acos, result, Zeros.Include);
    }

    protected override void DoPointwiseAsin(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Asin, result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseAtan(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Atan, result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseAtan2(Vector<Numerics.Complex32> other, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseAtan2(Numerics.Complex32 scalar, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseCeiling(Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseCos(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Cos, result, Zeros.Include);
    }

    protected override void DoPointwiseCosh(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Cosh, result, Zeros.Include);
    }

    protected override void DoPointwiseFloor(Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseLog10(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Log10, result, Zeros.Include);
    }

    protected override void DoPointwiseRound(Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseSign(Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseSin(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Sin, result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseSinh(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Sinh, result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseSqrt(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Sqrt, result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseTan(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Tan, result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseTanh(Vector<Numerics.Complex32> result) {
      Map(Numerics.Complex32.Tanh, result, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Computes the dot product between this vector and another vector.
    /// </summary>
    /// <param name="other">The other vector.</param>
    /// <returns>The sum of a[i]*b[i] for all i.</returns>
    protected override Numerics.Complex32 DoDotProduct(Vector<Numerics.Complex32> other) {
      var dot = Numerics.Complex32.Zero;
      for(var i = 0; i < Count; i++)
        dot += At(i) * other.At(i);

      return dot;
    }

    /// <summary>
    ///   Computes the dot product between the conjugate of this vector and another vector.
    /// </summary>
    /// <param name="other">The other vector.</param>
    /// <returns>The sum of conj(a[i])*b[i] for all i.</returns>
    protected override Numerics.Complex32 DoConjugateDotProduct(Vector<Numerics.Complex32> other) {
      var dot = Numerics.Complex32.Zero;
      for(var i = 0; i < Count; i++)
        dot += At(i).Conjugate() * other.At(i);

      return dot;
    }

    /// <summary>
    ///   Computes the canonical modulus, where the result has the sign of the divisor,
    ///   for each element of the vector for the given divisor.
    /// </summary>
    /// <param name="divisor">The scalar denominator to use.</param>
    /// <param name="result">A vector to store the results in.</param>
    protected sealed override void DoModulus(Numerics.Complex32 divisor, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Computes the canonical modulus, where the result has the sign of the divisor,
    ///   for the given dividend for each element of the vector.
    /// </summary>
    /// <param name="dividend">The scalar numerator to use.</param>
    /// <param name="result">A vector to store the results in.</param>
    protected sealed override void DoModulusByThis(Numerics.Complex32 dividend, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Computes the remainder (% operator), where the result has the sign of the dividend,
    ///   for each element of the vector for the given divisor.
    /// </summary>
    /// <param name="divisor">The scalar denominator to use.</param>
    /// <param name="result">A vector to store the results in.</param>
    protected sealed override void DoRemainder(Numerics.Complex32 divisor, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Computes the remainder (% operator), where the result has the sign of the dividend,
    ///   for the given dividend for each element of the vector.
    /// </summary>
    /// <param name="dividend">The scalar numerator to use.</param>
    /// <param name="result">A vector to store the results in.</param>
    protected sealed override void DoRemainderByThis(Numerics.Complex32 dividend, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseMinimum(Numerics.Complex32 scalar, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseMaximum(Numerics.Complex32 scalar, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseAbsoluteMinimum(Numerics.Complex32 scalar, Vector<Numerics.Complex32> result) {
      float absolute = scalar.Magnitude;
      Map(x => Math.Min(absolute, x.Magnitude), result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseAbsoluteMaximum(Numerics.Complex32 scalar, Vector<Numerics.Complex32> result) {
      float absolute = scalar.Magnitude;
      Map(x => Math.Max(absolute, x.Magnitude), result, Zeros.Include);
    }

    protected override void DoPointwiseMinimum(Vector<Numerics.Complex32> other, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseMaximum(Vector<Numerics.Complex32> other, Vector<Numerics.Complex32> result) {
      throw new NotSupportedException();
    }

    protected override void DoPointwiseAbsoluteMinimum(Vector<Numerics.Complex32> other,
                                                       Vector<Numerics.Complex32> result) {
      Map2((x, y) => Math.Min(x.Magnitude, y.Magnitude), other, result, Zeros.AllowSkip);
    }

    protected override void DoPointwiseAbsoluteMaximum(Vector<Numerics.Complex32> other,
                                                       Vector<Numerics.Complex32> result) {
      Map2((x, y) => Math.Max(x.Magnitude, y.Magnitude), other, result, Zeros.AllowSkip);
    }

    /// <summary>
    ///   Initializes a new instance of the Vector class.
    /// </summary>
    protected Vector(VectorStorage<Numerics.Complex32> storage)
      : base(storage) {
    }
  }

}