// Unity Asset Store License
//
// Copyright (c) 2016-2017 Bismur Studios Ltd.
// Copyright (c) 2016-2017 Ioannis Giagkiozis
//
// Math.NET for Unity is released under the Unity Asset Store 
// Terms of Service and EULA https://unity3d.com/legal/as_terms
// here-forth referred to simply as EULA.
// 
// Math.NET for Unity is a Non-Restricted Asset, as such section 2.2.2 
// of the EULA does not apply. Section 2.2.1 is applicable to Math.NET 
// for Unity, reproduced below:
// 
// 2.2.1 Non-Restricted Assets. The following concerns only Assets that 
// are not Restricted Assets: 
// Licensor grants to the END-USER a non-exclusive, worldwide, and 
// perpetual license to the Asset to integrate Assets only as incorporated 
// and embedded components of electronic games and interactive media 
// and distribute such electronic game and interactive media. Except for 
// game services software development kits (�Services SDKs�), END-USERS 
// may modify Assets. END-USER may otherwise not reproduce, distribute, 
// sublicense, rent, lease or lend the Assets. It is emphasized that the 
// END-USERS shall not be entitled to distribute or transfer in any way 
// (including, without, limitation by way of sublicense) the Assets in any 
// other way than as integrated components of electronic games and 
// interactive media. Without limitation of the foregoing it is emphasized 
// that END-USER shall not be entitled to share the costs related to purchasing 
// an Asset and then let any third party that has contributed to such purchase 
// use such Asset (forum pooling).
// 
// All other sections of the EULA apply.
// 
// CompositeSolver.cs is part of Math.NET for Unity.
// 
// A version of this file was part of Math.NET Numerics. 
// CompositeSolver.cs is a modified version of CompositeSolver.cs in Math.NET Numerics.
//
// ----------------------------------------------------------------------------
// License of the un-modified version of CompositeSolver.cs
// ----------------------------------------------------------------------------
//
// <copyright file="CompositeSolver.cs" company="Math.NET">
// Math.NET Numerics, part of the Math.NET Project
// http://numerics.mathdotnet.com
// http://github.com/mathnet/mathnet-numerics
//
// Copyright (c) 2009-2013 Math.NET
//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using MathNet.Numerics.LinearAlgebra.Solvers;
using MathNet.Numerics.Properties;


namespace MathNet.Numerics.LinearAlgebra.Complex.Solvers {

  /// <summary>
  ///   A composite matrix solver. The actual solver is made by a sequence of
  ///   matrix solvers.
  /// </summary>
  /// <remarks>
  ///   <para>
  ///     Solver based on:<br/>
  ///     Faster PDE-based simulations using robust composite linear solvers<br/>
  ///     S. Bhowmicka, P. Raghavan a,*, L. McInnes b, B. Norris<br/>
  ///     Future Generation Computer Systems, Vol 20, 2004, pp 373�387<br/>
  ///   </para>
  ///   <para>
  ///     Note that if an iterator is passed to this solver it will be used for all the sub-solvers.
  ///   </para>
  /// </remarks>
  public sealed class CompositeSolver : IIterativeSolver<Numerics.Complex> {
    /// <summary>
    ///   The collection of solvers that will be used
    /// </summary>
    readonly List<Tuple<IIterativeSolver<Numerics.Complex>, IPreconditioner<Numerics.Complex>>> _solvers;

    /// <summary>
    ///   Solves the matrix equation Ax = b, where A is the coefficient matrix, b is the
    ///   solution vector and x is the unknown vector.
    /// </summary>
    /// <param name="matrix">The coefficient matrix, <c>A</c>.</param>
    /// <param name="input">The solution vector, <c>b</c></param>
    /// <param name="result">The result vector, <c>x</c></param>
    /// <param name="iterator">The iterator to use to control when to stop iterating.</param>
    /// <param name="preconditioner">The preconditioner to use for approximations.</param>
    public void Solve(Matrix<Numerics.Complex> matrix, Vector<Numerics.Complex> input, Vector<Numerics.Complex> result,
                      Iterator<Numerics.Complex> iterator, IPreconditioner<Numerics.Complex> preconditioner) {
      if(matrix.RowCount != matrix.ColumnCount)
        throw new ArgumentException(Resources.ArgumentMatrixSquare, "matrix");

      if(result.Count != input.Count)
        throw new ArgumentException(Resources.ArgumentVectorsSameLength);

      if(iterator == null)
        iterator = new Iterator<Numerics.Complex>();

      if(preconditioner == null)
        preconditioner = new UnitPreconditioner<Numerics.Complex>();

      // Create a copy of the solution and result vectors so we can use them
      // later on
      var internalInput = input.Clone();
      var internalResult = result.Clone();

      foreach(var solver in _solvers) {
        // Store a reference to the solver so we can stop it.

        IterationStatus status;
        try {
          // Reset the iterator and pass it to the solver
          iterator.Reset();

          // Start the solver
          solver.Item1.Solve(matrix, internalInput, internalResult, iterator, solver.Item2 ?? preconditioner);
          status = iterator.Status;
        } catch(Exception) {
          // The solver broke down. 
          // Log a message about this
          // Switch to the next preconditioner. 
          // Reset the solution vector to the previous solution
          input.CopyTo(internalInput);
          continue;
        }

        // There was no fatal breakdown so check the status
        if(status == IterationStatus.Converged) {
          // We're done
          internalResult.CopyTo(result);
          break;
        }

        // We're not done
        // Either:
        // - calculation finished without convergence
        if(status == IterationStatus.StoppedWithoutConvergence)
          internalResult.CopyTo(result);
        else
          input.CopyTo(internalInput);
      }
    }

    public CompositeSolver(IEnumerable<IIterativeSolverSetup<Numerics.Complex>> solvers) {
      _solvers =
        solvers.Select(setup => new Tuple<IIterativeSolver<Numerics.Complex>, IPreconditioner<Numerics.Complex>>(
                                                                                                                 setup
                                                                                                                   .CreateSolver
                                                                                                                   (),
                                                                                                                 setup
                                                                                                                   .CreatePreconditioner
                                                                                                                   () ??
                                                                                                                 new UnitPreconditioner
                                                                                                                 <
                                                                                                                   Numerics
                                                                                                                   .
                                                                                                                   Complex
                                                                                                                 >()))
               .ToList();
    }
  }

}