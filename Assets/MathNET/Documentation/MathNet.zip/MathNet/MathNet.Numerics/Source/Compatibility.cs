﻿// Unity Asset Store License
//
// Copyright (c) 2016-2017 Bismur Studios Ltd.
// Copyright (c) 2016-2017 Ioannis Giagkiozis
//
// Math.NET for Unity is released under the Unity Asset Store 
// Terms of Service and EULA https://unity3d.com/legal/as_terms
// here-forth referred to simply as EULA.
// 
// Math.NET for Unity is a Non-Restricted Asset, as such section 2.2.2 
// of the EULA does not apply. Section 2.2.1 is applicable to Math.NET 
// for Unity, reproduced below:
// 
// 2.2.1 Non-Restricted Assets. The following concerns only Assets that 
// are not Restricted Assets: 
// Licensor grants to the END-USER a non-exclusive, worldwide, and 
// perpetual license to the Asset to integrate Assets only as incorporated 
// and embedded components of electronic games and interactive media 
// and distribute such electronic game and interactive media. Except for 
// game services software development kits (“Services SDKs”), END-USERS 
// may modify Assets. END-USER may otherwise not reproduce, distribute, 
// sublicense, rent, lease or lend the Assets. It is emphasized that the 
// END-USERS shall not be entitled to distribute or transfer in any way 
// (including, without, limitation by way of sublicense) the Assets in any 
// other way than as integrated components of electronic games and 
// interactive media. Without limitation of the foregoing it is emphasized 
// that END-USER shall not be entitled to share the costs related to purchasing 
// an Asset and then let any third party that has contributed to such purchase 
// use such Asset (forum pooling).
// 
// All other sections of the EULA apply.
// 
// Compatibility.cs is part of Math.NET for Unity.
// 
// A version of this file was part of Math.NET Numerics. 
// Compatibility.cs is a modified version of Compatibility.cs in Math.NET Numerics.
//
// ----------------------------------------------------------------------------
// License of the un-modified version of Compatibility.cs
// ----------------------------------------------------------------------------
//
// The original file had no license header.
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MathNet.Numerics.Properties;


namespace MathNet.Numerics {

  [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]
  public class SerializableAttribute : Attribute {
  }

  [AttributeUsage(AttributeTargets.Method, Inherited = false)]
  public class SpecialNameAttribute : Attribute {
  }

  internal static class Partitioner {
    public static IEnumerable<Tuple<int, int>> Create(int fromInclusive, int toExclusive) {
      var rangeSize = Math.Max(1, (toExclusive - fromInclusive) / Control.MaxDegreeOfParallelism);
      return Create(fromInclusive, toExclusive, rangeSize);
    }

    public static IEnumerable<Tuple<int, int>> Create(int fromInclusive, int toExclusive, int rangeSize) {
      if(toExclusive <= fromInclusive)
        throw new ArgumentOutOfRangeException("toExclusive");
      if(rangeSize <= 0)
        throw new ArgumentOutOfRangeException("rangeSize");

      return CreateRanges(fromInclusive, toExclusive, rangeSize);
    }

    static IEnumerable<Tuple<int, int>> CreateRanges(int fromInclusive, int toExclusive, int rangeSize) {
      bool flag = false;
      int num = fromInclusive;
      while(num < toExclusive && !flag) {
        int item = num;
        int num2;
        try {
          num2 = checked(num + rangeSize);
        } catch(OverflowException) {
          num2 = toExclusive;
          flag = true;
        }
        if(num2 > toExclusive)
          num2 = toExclusive;
        yield return new Tuple<int, int>(item, num2);

        num += rangeSize;
      }
    }
  }

  internal class ParallelOptions {
    public TaskScheduler TaskScheduler { get; set; }
    public int MaxDegreeOfParallelism { get; set; }
    public CancellationToken CancellationToken { get; set; }

    public ParallelOptions() {
      TaskScheduler = TaskScheduler.Default;
      MaxDegreeOfParallelism = -1;
      CancellationToken = CancellationToken.None;
    }
  }

  internal class ParallelLoopState {
  }

  internal static class Parallel {
    public static void ForEach<TSource>(IEnumerable<TSource> source, ParallelOptions parallelOptions,
                                        Action<TSource> body) {
      var chunks = source.ToArray();
      var tasks = new Task[chunks.Length];

      for(var i = 0; i < tasks.Length; i++) {
        var chunk = chunks[i];
        tasks[i] = Task.Factory.StartNew(
                                         () => body(chunk),
                                         parallelOptions.CancellationToken,
                                         TaskCreationOptions.None,
                                         parallelOptions.TaskScheduler);
      }

      Task.WaitAll(tasks, parallelOptions.CancellationToken);
    }

    public static void Invoke(ParallelOptions parallelOptions, params Action[] actions) {
      var tasks = new Task[actions.Length];

      for(var i = 0; i < tasks.Length; i++) {
        var action = actions[i];
        if(action == null)
          throw new ArgumentException(
                                      string.Format(Resources.ArgumentItemNull, "actions"),
                                      "actions");

        tasks[i] = Task.Factory.StartNew(
                                         action,
                                         parallelOptions.CancellationToken,
                                         TaskCreationOptions.None,
                                         parallelOptions.TaskScheduler);
      }

      Task.WaitAll(tasks, parallelOptions.CancellationToken);
    }

    public static void ForEach<TSource, TLocal>(
      IEnumerable<TSource> source,
      ParallelOptions parallelOptions,
      Func<TLocal> localInit,
      Func<TSource, ParallelLoopState, TLocal, TLocal> body,
      Action<TLocal> localFinally) {
      var chunks = source.ToArray();
      var tasks = new Task[chunks.Length];
      var loopState = new ParallelLoopState();

      for(var i = 0; i < tasks.Length; i++) {
        var chunk = chunks[i];
        tasks[i] = Task.Factory.StartNew(() => {
                                           var local = localInit();
                                           local = body(chunk, loopState, local);
                                           localFinally(local);
                                         },
                                         parallelOptions.CancellationToken,
                                         TaskCreationOptions.None,
                                         parallelOptions.TaskScheduler);
      }

      Task.WaitAll(tasks, parallelOptions.CancellationToken);
    }
  }

}


namespace MathNet.Numerics {

  [AttributeUsage(AttributeTargets.Constructor | AttributeTargets.Method, Inherited = false)]
  public class TargetedPatchingOptOutAttribute : Attribute {
    public string Reason { get; private set; }

    public TargetedPatchingOptOutAttribute(string reason) {
      Reason = reason;
    }
  }

}


namespace MathNet.Numerics {

  internal static class ObjectComparer {
    internal static int Compare<T>(T a, T b) {
      if(ReferenceEquals(a, null))
        return -1;
      if(ReferenceEquals(b, null))
        return 1;
      if(Equals(a, b))
        return 0;

      return Comparer<T>.Default.Compare(a, b);
    }
  }

  /// <summary>
  ///   Tuple.
  /// </summary>
  public class Tuple<T1, T2> : IComparable, IComparable<Tuple<T1, T2>> {
    public T1 Item1 { get; set; }
    public T2 Item2 { get; set; }

    /// <summary>
    ///   Compares to.
    /// </summary>
    /// <returns>The to.</returns>
    /// <param name="obj">Object.</param>
    public int CompareTo(object obj) {
      if(obj == null)
        return 1;

      var other = obj as Tuple<T1, T2>;
      if(other == null)
        throw new ArgumentException();

      return CompareTo(other);
    }

    /// <summary>
    ///   Compares to.
    /// </summary>
    /// <returns>The to.</returns>
    /// <param name="other">Other.</param>
    public int CompareTo(Tuple<T1, T2> other) {
      if(other == null)
        return 1;

      int a = ObjectComparer.Compare(Item1, other.Item1);
      return a != 0 ? a : ObjectComparer.Compare(Item2, other.Item2);
    }

    /// <summary>
    ///   Initializes a new instance of the <see cref="T:MathNet.Numerics.Tuple`2"/> class.
    /// </summary>
    /// <param name="item1">Item1.</param>
    /// <param name="item2">Item2.</param>
    public Tuple(T1 item1, T2 item2) {
      Item1 = item1;
      Item2 = item2;
    }
  }

  /// <summary>
  ///   Tuple.
  /// </summary>
  public class Tuple<T1, T2, T3> : IComparable, IComparable<Tuple<T1, T2, T3>> {
    public T1 Item1 { get; set; }
    public T2 Item2 { get; set; }
    public T3 Item3 { get; set; }

    /// <summary>
    ///   Compares to.
    /// </summary>
    /// <returns>The to.</returns>
    /// <param name="obj">Object.</param>
    public int CompareTo(object obj) {
      if(obj == null)
        return 1;

      var other = obj as Tuple<T1, T2, T3>;
      if(other == null)
        throw new ArgumentException();

      return CompareTo(other);
    }

    /// <summary>
    ///   Compares to.
    /// </summary>
    /// <returns>The to.</returns>
    /// <param name="other">Other.</param>
    public int CompareTo(Tuple<T1, T2, T3> other) {
      if(other == null)
        return 1;

      int a = ObjectComparer.Compare(Item1, other.Item1);
      if(a != 0)
        return a;

      int b = ObjectComparer.Compare(Item2, other.Item2);
      return b != 0 ? b : ObjectComparer.Compare(Item3, other.Item3);
    }

    /// <summary>
    ///   Initializes a new instance of the <see cref="T:MathNet.Numerics.Tuple`3"/> class.
    /// </summary>
    /// <param name="item1">Item1.</param>
    /// <param name="item2">Item2.</param>
    /// <param name="item3">Item3.</param>
    public Tuple(T1 item1, T2 item2, T3 item3) {
      Item1 = item1;
      Item2 = item2;
      Item3 = item3;
    }
  }

  /// <summary>
  ///   Tuple.
  /// </summary>
  public class Tuple<T1, T2, T3, T4> : IComparable, IComparable<Tuple<T1, T2, T3, T4>> {
    public T1 Item1 { get; set; }
    public T2 Item2 { get; set; }
    public T3 Item3 { get; set; }
    public T4 Item4 { get; set; }

    /// <summary>
    ///   Compares to.
    /// </summary>
    /// <returns>The to.</returns>
    /// <param name="obj">Object.</param>
    public int CompareTo(object obj) {
      if(obj == null)
        return 1;

      var other = obj as Tuple<T1, T2, T3, T4>;
      if(other == null)
        throw new ArgumentException();

      return CompareTo(other);
    }

    /// <summary>
    ///   Compares to.
    /// </summary>
    /// <returns>The to.</returns>
    /// <param name="other">Other.</param>
    public int CompareTo(Tuple<T1, T2, T3, T4> other) {
      if(other == null)
        return 1;

      int a = ObjectComparer.Compare(Item1, other.Item1);
      if(a != 0)
        return a;

      int b = ObjectComparer.Compare(Item2, other.Item2);
      if(b != 0)
        return b;

      int c = ObjectComparer.Compare(Item3, other.Item3);
      return c != 0 ? c : ObjectComparer.Compare(Item4, other.Item4);
    }

    /// <summary>
    ///   Initializes a new instance of the <see cref="T:MathNet.Numerics.Tuple`4"/> class.
    /// </summary>
    /// <param name="item1">Item1.</param>
    /// <param name="item2">Item2.</param>
    /// <param name="item3">Item3.</param>
    /// <param name="item4">Item4.</param>
    public Tuple(T1 item1, T2 item2, T3 item3, T4 item4) {
      Item1 = item1;
      Item2 = item2;
      Item3 = item3;
      Item4 = item4;
    }
  }

  /// <summary>
  ///   Enumerable extensions.
  /// </summary>
  public static class EnumerableExtensions {
    public static IEnumerable<T> Zip<TA, TB, T>(this IEnumerable<TA> seqA, IEnumerable<TB> seqB, Func<TA, TB, T> func) {
      if(seqA == null)
        throw new ArgumentNullException("seqA");
      if(seqB == null)
        throw new ArgumentNullException("seqB");

      return Zip35Deferred(seqA, seqB, func);
    }

    static IEnumerable<T> Zip35Deferred<A, B, T>(IEnumerable<A> seqA, IEnumerable<B> seqB, Func<A, B, T> func) {
      using(var iteratorA = seqA.GetEnumerator())
      using(var iteratorB = seqB.GetEnumerator())
        while(iteratorA.MoveNext() && iteratorB.MoveNext())
          yield return func(iteratorA.Current, iteratorB.Current);
    }
  }

}