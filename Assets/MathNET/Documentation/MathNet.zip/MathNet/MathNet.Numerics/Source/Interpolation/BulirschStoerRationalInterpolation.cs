﻿// Unity Asset Store License
//
// Copyright (c) 2016-2017 Bismur Studios Ltd.
// Copyright (c) 2016-2017 Ioannis Giagkiozis
//
// Math.NET for Unity is released under the Unity Asset Store 
// Terms of Service and EULA https://unity3d.com/legal/as_terms
// here-forth referred to simply as EULA.
// 
// Math.NET for Unity is a Non-Restricted Asset, as such section 2.2.2 
// of the EULA does not apply. Section 2.2.1 is applicable to Math.NET 
// for Unity, reproduced below:
// 
// 2.2.1 Non-Restricted Assets. The following concerns only Assets that 
// are not Restricted Assets: 
// Licensor grants to the END-USER a non-exclusive, worldwide, and 
// perpetual license to the Asset to integrate Assets only as incorporated 
// and embedded components of electronic games and interactive media 
// and distribute such electronic game and interactive media. Except for 
// game services software development kits (“Services SDKs”), END-USERS 
// may modify Assets. END-USER may otherwise not reproduce, distribute, 
// sublicense, rent, lease or lend the Assets. It is emphasized that the 
// END-USERS shall not be entitled to distribute or transfer in any way 
// (including, without, limitation by way of sublicense) the Assets in any 
// other way than as integrated components of electronic games and 
// interactive media. Without limitation of the foregoing it is emphasized 
// that END-USER shall not be entitled to share the costs related to purchasing 
// an Asset and then let any third party that has contributed to such purchase 
// use such Asset (forum pooling).
// 
// All other sections of the EULA apply.
// 
// BulirschStoerRationalInterpolation.cs is part of Math.NET for Unity.
// 
// A version of this file was part of Math.NET Numerics. 
// BulirschStoerRationalInterpolation.cs is a modified version of BulirschStoerRationalInterpolation.cs in Math.NET Numerics.
//
// ----------------------------------------------------------------------------
// License of the un-modified version of BulirschStoerRationalInterpolation.cs
// ----------------------------------------------------------------------------
//
// <copyright file="BulirschStoerRationalInterpolation.cs" company="Math.NET">
// Math.NET Numerics, part of the Math.NET Project
// http://numerics.mathdotnet.com
// http://github.com/mathnet/mathnet-numerics
//
// Copyright (c) 2009-2014 Math.NET
//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using MathNet.Numerics.Properties;


namespace MathNet.Numerics.Interpolation {

  /// <summary>
  ///   Rational Interpolation (with poles) using Roland Bulirsch and Josef Stoer's Algorithm.
  /// </summary>
  /// <remarks>
  ///   <para>
  ///     This algorithm supports neither differentiation nor integration.
  ///   </para>
  /// </remarks>
  public class BulirschStoerRationalInterpolation : IInterpolation {
    readonly double[] _x;
    readonly double[] _y;

    /// <summary>
    ///   Create a Bulirsch-Stoer rational interpolation from a set of (x,y) value pairs, sorted ascendingly by x.
    /// </summary>
    public static BulirschStoerRationalInterpolation InterpolateSorted(double[] x, double[] y) {
      return new BulirschStoerRationalInterpolation(x, y);
    }

    /// <summary>
    ///   Create a Bulirsch-Stoer rational interpolation from an unsorted set of (x,y) value pairs.
    ///   WARNING: Works in-place and can thus causes the data array to be reordered.
    /// </summary>
    public static BulirschStoerRationalInterpolation InterpolateInplace(double[] x, double[] y) {
      if(x.Length != y.Length)
        throw new ArgumentException(Resources.ArgumentVectorsSameLength);

      Sorting.Sort(x, y);
      return InterpolateSorted(x, y);
    }

    /// <summary>
    ///   Create a Bulirsch-Stoer rational interpolation from an unsorted set of (x,y) value pairs.
    /// </summary>
    public static BulirschStoerRationalInterpolation Interpolate(IEnumerable<double> x, IEnumerable<double> y) {
      // note: we must make a copy, even if the input was arrays already
      return InterpolateInplace(x.ToArray(), y.ToArray());
    }

    /// <summary>
    ///   Interpolate at point t.
    /// </summary>
    /// <param name="t">Point t to interpolate at.</param>
    /// <returns>Interpolated value x(t).</returns>
    public double Interpolate(double t) {
      const double tiny = 1.0e-25;
      int n = _x.Length;

      var c = new double[n];
      var d = new double[n];

      int nearestIndex = 0;
      double nearestDistance = Math.Abs(t - _x[0]);

      for(int i = 0; i < n; i++) {
        double distance = Math.Abs(t - _x[i]);
        if(distance.AlmostEqual(0.0))
          return _y[i];

        if(distance < nearestDistance) {
          nearestIndex = i;
          nearestDistance = distance;
        }

        c[i] = _y[i];
        d[i] = _y[i] + tiny;
      }

      double x = _y[nearestIndex];

      for(int level = 1; level < n; level++) {
        for(int i = 0; i < n - level; i++) {
          double hp = _x[i + level] - t;
          double ho = (_x[i] - t) * d[i] / hp;

          double den = ho - c[i + 1];
          if(den.AlmostEqual(0.0))
            return double.NaN; // zero-div, singularity

          den = (c[i + 1] - d[i]) / den;
          d[i] = c[i + 1] * den;
          c[i] = ho * den;
        }

        x += 2 * nearestIndex < n - level
               ? c[nearestIndex]
               : d[--nearestIndex];
      }

      return x;
    }

    /// <param name="x">Sample Points t, sorted ascendingly.</param>
    /// <param name="y">Sample Values x(t), sorted ascendingly by x.</param>
    public BulirschStoerRationalInterpolation(double[] x, double[] y) {
      if(x.Length != y.Length)
        throw new ArgumentException(Resources.ArgumentVectorsSameLength);

      if(x.Length < 1)
        throw new ArgumentException(string.Format(Resources.ArrayTooSmall, 1), "x");

      _x = x;
      _y = y;
    }

    /// <summary>
    ///   Gets a value indicating whether the algorithm supports differentiation (interpolated derivative).
    /// </summary>
    bool IInterpolation.SupportsDifferentiation {
      get { return false; }
    }

    /// <summary>
    ///   Gets a value indicating whether the algorithm supports integration (interpolated quadrature).
    /// </summary>
    bool IInterpolation.SupportsIntegration {
      get { return false; }
    }

    /// <summary>
    ///   Differentiate at point t. NOT SUPPORTED.
    /// </summary>
    /// <param name="t">Point t to interpolate at.</param>
    /// <returns>Interpolated first derivative at point t.</returns>
    double IInterpolation.Differentiate(double t) {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Differentiate twice at point t. NOT SUPPORTED.
    /// </summary>
    /// <param name="t">Point t to interpolate at.</param>
    /// <returns>Interpolated second derivative at point t.</returns>
    double IInterpolation.Differentiate2(double t) {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Indefinite integral at point t. NOT SUPPORTED.
    /// </summary>
    /// <param name="t">Point t to integrate at.</param>
    double IInterpolation.Integrate(double t) {
      throw new NotSupportedException();
    }

    /// <summary>
    ///   Definite integral between points a and b. NOT SUPPORTED.
    /// </summary>
    /// <param name="a">Left bound of the integration interval [a,b].</param>
    /// <param name="b">Right bound of the integration interval [a,b].</param>
    double IInterpolation.Integrate(double a, double b) {
      throw new NotSupportedException();
    }
  }

}