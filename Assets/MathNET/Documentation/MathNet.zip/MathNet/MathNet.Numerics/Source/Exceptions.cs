﻿// Unity Asset Store License
//
// Copyright (c) 2016-2017 Bismur Studios Ltd.
// Copyright (c) 2016-2017 Ioannis Giagkiozis
//
// Math.NET for Unity is released under the Unity Asset Store 
// Terms of Service and EULA https://unity3d.com/legal/as_terms
// here-forth referred to simply as EULA.
// 
// Math.NET for Unity is a Non-Restricted Asset, as such section 2.2.2 
// of the EULA does not apply. Section 2.2.1 is applicable to Math.NET 
// for Unity, reproduced below:
// 
// 2.2.1 Non-Restricted Assets. The following concerns only Assets that 
// are not Restricted Assets: 
// Licensor grants to the END-USER a non-exclusive, worldwide, and 
// perpetual license to the Asset to integrate Assets only as incorporated 
// and embedded components of electronic games and interactive media 
// and distribute such electronic game and interactive media. Except for 
// game services software development kits (“Services SDKs”), END-USERS 
// may modify Assets. END-USER may otherwise not reproduce, distribute, 
// sublicense, rent, lease or lend the Assets. It is emphasized that the 
// END-USERS shall not be entitled to distribute or transfer in any way 
// (including, without, limitation by way of sublicense) the Assets in any 
// other way than as integrated components of electronic games and 
// interactive media. Without limitation of the foregoing it is emphasized 
// that END-USER shall not be entitled to share the costs related to purchasing 
// an Asset and then let any third party that has contributed to such purchase 
// use such Asset (forum pooling).
// 
// All other sections of the EULA apply.
// 
// Exceptions.cs is part of Math.NET for Unity.
// 
// A version of this file was part of Math.NET Numerics. 
// Exceptions.cs is a modified version of Exceptions.cs in Math.NET Numerics.
//
// ----------------------------------------------------------------------------
// License of the un-modified version of Exceptions.cs
// ----------------------------------------------------------------------------
//
// The original file had no license header.
//
using System;
using System.Runtime.Serialization;
using MathNet.Numerics.Properties;


namespace MathNet.Numerics {

  /// <summary>
  ///   An algorithm failed to converge.
  /// </summary>
  [Serializable]
  public class NonConvergenceException : Exception {
    public NonConvergenceException()
      : base(Resources.ConvergenceFailed) {
    }

    public NonConvergenceException(string message)
      : base(message) {
    }

    public NonConvergenceException(string message, Exception innerException)
      : base(message, innerException) {
    }

    protected NonConvergenceException(SerializationInfo info, StreamingContext context)
      : base(info, context) {
    }
  }

  /// <summary>
  ///   An algorithm failed to converge due to a numerical breakdown.
  /// </summary>
  [Serializable]
  public class NumericalBreakdownException : NonConvergenceException {
    public NumericalBreakdownException()
      : base(Resources.NumericalBreakdown) {
    }

    public NumericalBreakdownException(string message)
      : base(message) {
    }

    public NumericalBreakdownException(string message, Exception innerException)
      : base(message, innerException) {
    }

    protected NumericalBreakdownException(SerializationInfo info, StreamingContext context)
      : base(info, context) {
    }
  }

  /// <summary>
  ///   An error occured calling native provider function.
  /// </summary>
  [Serializable]
  public abstract class NativeInterfaceException : Exception {
    protected NativeInterfaceException() {
    }

    protected NativeInterfaceException(string message)
      : base(message) {
    }

    protected NativeInterfaceException(string message, Exception innerException)
      : base(message, innerException) {
    }

    protected NativeInterfaceException(SerializationInfo info, StreamingContext context)
      : base(info, context) {
    }
  }

  /// <summary>
  ///   An error occured calling native provider function.
  /// </summary>
  [Serializable]
  public class InvalidParameterException : NativeInterfaceException {
    public InvalidParameterException()
      : base(Resources.InvalidParameter) {
    }

    public InvalidParameterException(int parameter)
      : base(string.Format(Resources.InvalidParameterWithNumber, parameter)) {
    }

    public InvalidParameterException(int parameter, Exception innerException)
      : base(string.Format(Resources.InvalidParameterWithNumber, parameter), innerException) {
    }

    protected InvalidParameterException(SerializationInfo info, StreamingContext context)
      : base(info, context) {
    }
  }

  /// <summary>
  ///   Native provider was unable to allocate sufficent memory.
  /// </summary>
  [Serializable]
  public class MemoryAllocationException : NativeInterfaceException {
    public MemoryAllocationException()
      : base(Resources.MemoryAllocation) {
    }

    public MemoryAllocationException(Exception innerException)
      : base(Resources.MemoryAllocation, innerException) {
    }

    protected MemoryAllocationException(SerializationInfo info, StreamingContext context)
      : base(info, context) {
    }
  }

  /// <summary>
  ///   Native provider failed LU inversion do to a singular U matrix.
  /// </summary>
  [Serializable]
  public class SingularUMatrixException : NativeInterfaceException {
    public SingularUMatrixException()
      : base(Resources.SingularUMatrix) {
    }

    public SingularUMatrixException(int element)
      : base(string.Format(Resources.SingularUMatrixWithElement, element)) {
    }

    public SingularUMatrixException(int element, Exception innerException)
      : base(string.Format(Resources.SingularUMatrixWithElement, element), innerException) {
    }

    protected SingularUMatrixException(SerializationInfo info, StreamingContext context)
      : base(info, context) {
    }
  }

}