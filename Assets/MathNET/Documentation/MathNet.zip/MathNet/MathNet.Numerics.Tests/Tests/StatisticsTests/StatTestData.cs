using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;


namespace MathNet.Numerics.UnitTests.StatisticsTests {

  /// <summary>
  ///   Statistics data.
  /// </summary>
  internal class StatTestData {
    /// <summary>
    ///   Data array.
    /// </summary>
    public readonly double[] Data;

    /// <summary>
    ///   Data with nulls.
    /// </summary>
    public readonly double?[] DataWithNulls;

    /// <summary>
    ///   Mean value.
    /// </summary>
    public readonly double Mean;

    /// <summary>
    ///   Standard Deviation.
    /// </summary>
    public readonly double StandardDeviation;

    /// <summary>
    ///   Initializes a new instance of the StatTestData class.
    /// </summary>
    /// <param name="file">Path to the file.</param>
    public StatTestData(string file) {
      using(var reader = TestData.Data.ReadText(file)) {
        var line = reader.ReadLine().Trim();

        while(!line.StartsWith("--")) {
          if(line.StartsWith("Sample Mean"))
            Mean = GetValue(line);
          else if(line.StartsWith("Sample Standard Deviation"))
            StandardDeviation = GetValue(line);

          line = reader.ReadLine().Trim();
        }

        line = reader.ReadLine();

        IList<double> list = new List<double>();
        while(line != null) {
          line = line.Trim();
          if(!line.Equals(string.Empty))
            list.Add(double.Parse(line, CultureInfo.InvariantCulture));

          line = reader.ReadLine();
        }

        Data = list.ToArray();
      }

      DataWithNulls = new double?[Data.Length + 2];
      for(var i = 0; i < Data.Length; i++)
        DataWithNulls[i + 1] = Data[i];
    }

    /// <summary>
    ///   Get value.
    /// </summary>
    /// <param name="str">Parameter name.</param>
    /// <returns>Parameter value.</returns>
    static double GetValue(string str) {
      var start = str.IndexOf(":", StringComparison.Ordinal);
      var value = str.Substring(start + 1).Trim();
      if(value.Equals("NaN"))
        return 0;

      return double.Parse(str.Substring(start + 1).Trim(), CultureInfo.InvariantCulture);
    }
  }

}