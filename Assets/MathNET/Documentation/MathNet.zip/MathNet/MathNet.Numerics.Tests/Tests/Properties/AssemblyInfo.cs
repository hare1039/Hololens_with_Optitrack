﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly:AssemblyTitle("Math.NET Numerics Unit Tests")]
[assembly:AssemblyCompany("Math.NET Project")]
[assembly:AssemblyProduct("Math.NET Numerics")]
[assembly:AssemblyCopyright("Copyright (c) Math.NET Project")]
[assembly:ComVisible(false)]
[assembly:Guid("04157581-63f3-447b-a277-83c6e69126a4")]
[assembly:AssemblyVersion("3.14.0.0")]
[assembly:AssemblyFileVersion("3.14.0.0")]
[assembly:AssemblyInformationalVersion("3.14.0-beta03")]